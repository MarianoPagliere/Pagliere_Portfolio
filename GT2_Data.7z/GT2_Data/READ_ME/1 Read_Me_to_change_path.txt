- Por favor, en order de que el código funcione recuerda cambiar "databse_path", del "input_path", ademas de los 3 "output_path" de insert, delete y update.

- Por favor, respete la DOBLE CONTRABARRA -> "\\"

- El path puede ser cambiado una vez haya descargado los archivos:

1  Haga click derecho sobre el archivos "GT2_CarList_Data.db" en la carpeta "GT2_db".

2  Elija la opción "Copiar como ruta de acceso" o "Ctrl + Shift + C"

3  Suplantelo por el path anterior en la linea 239 y recuerde agregar las DOBLE CONTRABRRAS -> "\\"

4  Repita el procedimiento 2 para el archivo excel "GT2_CarList_Data.csv" en la carpeta "GT2_db"

5  Suplantelo por el path anterior en la linea 243 y recuerde agregar las DOBLE CONTRABRRAS -> "\\"

6  Elija un path para la creación de archivos .csv resultado de las operaciones insert, baja y update.