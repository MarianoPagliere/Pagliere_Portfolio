import sqlite3
import pandas as pd
import random

def get_input(prompt: str, is_int: bool = False) -> str:
    while True:
        user_input = input(prompt)
        if user_input.upper() == "ESC":
            print("Regresando al menú principal.")
            return None
        if is_int:
            try:
                return int(user_input)
            except ValueError:
                print("Por favor, ingresa un número válido o 'ESC' para salir.")
        else:
            return user_input

def get_car_data():
    prompts = [
        ("Tipea el ID del Auto:", True),
        ("Tipea la MARCA del auto:", False),
        ("Tipea el MODELO del auto:", False),
        ("Tipea el PRECIO del auto:", True),
        ("Tipea el AÑO del auto:", False),
        ("Tipea la disposición del auto:", False),
        ("Tipea el tipo de motor del auto:", False),
        ("Tipea los HP del auto:", True),
        ("Tipea el PESO en LIBRAS del auto:", True),
        ("Tipea el PESO en KILOS del auto:", True),
        ("Tipea la CONFIGURACION DE CILINDROS del auto:", False),
        ("Tipea la CILINDRADA del auto:", True),
        ("Tipea la LONGITUD del auto:", True),
        ("Tipea el ANCHO del auto:", True),
        ("Tipea el ALTO del auto:", True),
        ("Tipea el número de la TIENDA DE TUNEO del auto:", True),
        ("Tipea el KIT del auto:", False),
        ("Tipea el MAKE ID del auto:", True),
        ("Tipea la CONDICION del auto:", False),
        ("Tipea el PAIS del auto:", False),
        ("Tipea la CIUDAD del auto:", False)
    ]
    
    car_data = []
    for prompt, is_int in prompts:
        data = get_input(prompt, is_int)
        if data is None:
            return None
        car_data.append(data)
    return car_data

def insert_car_record(database_path, csv_output_path):
    car_data = get_car_data()
    if car_data is None:
        return

    try:
        with sqlite3.connect(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''INSERT INTO CarList (CarList_ID,Make_Name,Model_Name,Price,Year,Drivetrain,Engine_Type,HP,Weight_Imperial,Weight_Metric,Cylinder_Config,Displacement,Length,Width,Height,Tune_Shop_ID,Tune_Kit_ID,Make_ID,Condition,Country,City)
                              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', car_data) 
            conn.commit()
            
            cursor.execute('SELECT * FROM CarList')
            results = cursor.fetchall()
            cursor.close()
            
            car_list_df = pd.DataFrame(results)
            print(car_list_df)
            car_list_df.to_csv(csv_output_path, index=False)
            print(f"Datos guardados en {csv_output_path}")

    except sqlite3.Error as e:
        print(f"Error al trabajar con la base de datos: {e}")

def delete_car_record(database_path, csv_output_path):
    car_id = get_input("Tipea el ID del Auto a borrar: ", True)
    if car_id is None:
        return

    try:
        with sqlite3.connect(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM CarList WHERE CarList_ID = ?', (car_id,))
            conn.commit()
            
            cursor.execute('SELECT * FROM CarList')
            results = cursor.fetchall()
            cursor.close()
            
            car_list_df = pd.DataFrame(results)
            print(car_list_df)
            car_list_df.to_csv(csv_output_path, index=False)
            print(f"Datos restantes guardados en {csv_output_path}")

    except sqlite3.Error as e:
        print(f"Error al trabajar con la base de datos: {e}")

def update_car_record(database_path, csv_output_path):
    car_id = get_input("Tipea el ID del Auto a actualizar: ", True)
    if car_id is None:
        return

    field_prompts = {
        "Make_Name": "Tipea la nueva MARCA del auto: ",
        "Model_Name": "Tipea el nuevo MODELO del auto: ",
        "Price": "Tipea el nuevo PRECIO del auto: ",
        "Year": "Tipea el nuevo AÑO del auto: ",
        "Drivetrain": "Tipea la nueva disposición del auto: ",
        "Engine_Type": "Tipea el nuevo tipo de motor del auto: ",
        "HP": "Tipea los nuevos HP del auto: ",
        "Weight_Imperial": "Tipea el nuevo PESO en LIBRAS del auto: ",
        "Weight_Metric": "Tipea el nuevo PESO en KILOS del auto: ",
        "Cylinder_Config": "Tipea la nueva CONFIGURACION DE CILINDROS del auto: ",
        "Displacement": "Tipea la nueva CILINDRADA del auto: ",
        "Length": "Tipea la nueva LONGITUD del auto: ",
        "Width": "Tipea el nuevo ANCHO del auto: ",
        "Height": "Tipea el nuevo ALTO del auto: ",
        "Tune_Shop_ID": "Tipea el nuevo número de la TIENDA DE TUNEO del auto: ",
        "Tune_Kit_ID": "Tipea el nuevo KIT del auto: ",
        "Make_ID": "Tipea el nuevo MAKE ID del auto: ",
        "Condition": "Tipea la nueva CONDICION del auto: ",
        "Country": "Tipea el nuevo PAIS del auto: ",
        "City": "Tipea la nueva CIUDAD del auto: "
    }
    
    while True:
        field_to_update = input("Elige el campo a actualizar: " + ", ".join(field_prompts.keys()) + " o 'ESC' para salir: ").strip()
        if field_to_update.upper() == "ESC":
            print("Regresando al menú principal.")
            return
        if field_to_update in field_prompts:
            new_value = get_input(field_prompts[field_to_update], is_int=field_to_update in ["Price", "HP", "Weight_Imperial", "Weight_Metric", "Displacement", "Length", "Width", "Height", "Tune_Shop_ID", "Make_ID"])
            if new_value is None:
                return
            break
        else:
            print("Campo no válido. Por favor, elige un campo válido o 'ESC' para salir.")

    try:
        with sqlite3.connect(database_path) as conn:
            cursor = conn.cursor()
            query = f'UPDATE CarList SET {field_to_update} = ? WHERE CarList_ID = ?'
            cursor.execute(query, (new_value, car_id))
            conn.commit()
            
            cursor.execute('SELECT * FROM CarList')
            results = cursor.fetchall()
            cursor.close()
            
            car_list_df = pd.DataFrame(results)
            print(car_list_df)
            car_list_df.to_csv(csv_output_path, index=False)
            print(f"Datos actualizados guardados en {csv_output_path}")

    except sqlite3.Error as e:
        print(f"Error al trabajar con la base de datos: {e}")

def filter_car_records(csv_path):
    # Lee el archivo CSV
    df = pd.read_csv(csv_path)

    # Función para obtener la ciudad del usuario
    def get_city() -> str:
        return input("Tipea tu ciudad: ")

    # Función para obtener el HP máximo del usuario
    def get_max_hp() -> int:
        while True:
            try:
                return int(input("Elegi tu HP máximo: "))
            except ValueError:
                print("Por favor, ingresa un número válido.")

    # Función para obtener el peso mínimo del usuario
    def get_min_weight() -> int:
        while True:
            try:
                return int(input("Elegi tu Peso mínimo: "))
            except ValueError:
                print("Por favor, ingresa un número válido.")

    # Obtiene los valores del input del usuario
    city = get_city()
    max_hp = get_max_hp()
    min_weight = get_min_weight()

    # Filtra el DataFrame
    filtered_df = df.loc[
        (df['City'] == city) & 
        (df['HP'] < max_hp) & 
        (df['Weight_Metric'] >= min_weight)
    ]


    print(filtered_df)

def filter_random_car_records(csv_path):
    
    df = pd.read_csv(csv_path)

    # Función para obtener una ciudad aleatoria
    def get_random_city() -> str:
        Lista_Ciudades = ["North", "East", "West", "South"]
        return random.choice(Lista_Ciudades)

    # Función para obtener un HP máximo aleatorio
    def get_random_max_hp() -> int:
        Lista_HP = [64, 69, 70, 75, 80, 85, 90, 95, 99, 100, 110, 115, 120, 130, 132, 135, 140, 145, 147, 150, 152, 155, 160, 165, 169, 170, 175, 180, 182, 185, 190, 196, 199, 200, 206, 222, 240, 250, 255, 260, 270, 290, 299, 300, 303, 310, 315, 325, 350, 370, 399, 400, 420, 440, 450, 480, 499, 500, 525, 550, 555, 560, 590, 600, 650, 666]
        return random.choice(Lista_HP)

    # Función para obtener un peso mínimo aleatorio
    def get_random_min_weight() -> int:
        Lista_Peso = [640, 700, 720, 750, 799, 800, 820, 850, 900, 920, 950, 970, 980, 990, 999, 1000, 1050, 1099, 1100, 1120, 1150, 1190, 1200, 1220, 1250, 1290, 1300, 1320, 1340, 1355, 1370, 1390, 1400, 1420, 1444, 1455, 1480, 1501]
        return random.choice(Lista_Peso)

    
    city = get_random_city()
    max_hp = get_random_max_hp()
    min_weight = get_random_min_weight()

    # Muestra los valores seleccionados
    print(f"La ciudad del fabricante es: {city}.")
    print(f"El máximo de HP permitido es: {max_hp} HP.")
    print(f"El PESO mínimo permitido del auto es: {min_weight} Kg")

    # Filtra el DataFrame
    filtered_df = df.loc[
        (df['City'] == city) & 
        (df['HP'] < max_hp) & 
        (df['Weight_Metric'] >= min_weight)
    ]

    
    print(filtered_df)


def main():
    database_path = "C:\\Users\\Marian\\Desktop\\GT2_Data\\GT2_db\\GT2_CarList_Data.db"
    csv_output_path_insert = "C:\\Users\\Marian\\Desktop\\GT2_Data\\GT2_py\\ALTA.csv"
    csv_output_path_delete = "C:\\Users\\Marian\\Desktop\\GT2_Data\\GT2_py\\BAJA.csv"
    csv_output_path_update = "C:\\Users\\Marian\\Desktop\\GT2_Data\\GT2_py\\UPDATE.csv"
    csv_input_path = "C:\\Users\\Marian\\Desktop\\GT2_Data\\GT2_db\\GT2_CarList_Data.csv"

    while True:
        action = input("Elige una opción (nuevo registro / eliminar registro / actualizar registro / filtrar por input / filtrado random / ESC para salir): ").strip().lower()
        if action == "nuevo registro":
            insert_car_record(database_path, csv_output_path_insert)
        elif action == "eliminar registro":
            delete_car_record(database_path, csv_output_path_delete)
        elif action == "actualizar registro":
            update_car_record(database_path, csv_output_path_update)
        elif action == "filtrar por input":
            filter_car_records(csv_input_path)
        elif action == "filtrado random":
            filter_random_car_records(csv_input_path)
        elif action == "esc":
            print("Saliendo del programa.")
            break
        else:
            print("Opción no válida. Por favor, elige 'nuevo registro', 'eliminar registro', 'actualizar registro', 'filtrar por input', 'filtrado random' o 'ESC' para salir.")

if __name__ == "__main__":
    main()